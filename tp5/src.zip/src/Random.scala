import scala.math.random;

object Random extends App{
	while(true) println((random*2-1)+" "+(random*2-1));
}